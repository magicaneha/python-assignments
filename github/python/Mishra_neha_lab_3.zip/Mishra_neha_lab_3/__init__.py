class Triangle:
    def __init__(self, three_points, two_angles):
         self.points =  three_points
         self.angles =  two_angles


    def get_angles(self):
     third = self.third_angle()
     self.angles.append(third)
     return self.angles

    def third_angle(self):
        third_angle = 180 - (self.angles[0] + self.angles[1])  # calculating the third angle by property
        return third_angle

